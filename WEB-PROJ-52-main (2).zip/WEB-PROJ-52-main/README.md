# WEB-PROJ-52
HELLO!

and welcome to the web project github page, this is where we will assign, discuss and implement our solution (this is yapping for the TA please ignore)
incase anyone forgot, you have to drag and drop your changed files into the box above with all the folders and make a pull request to add your code into the codebase, make sure before you download the codebase that its the latest version, I will try my best to check pull requests everyday.
